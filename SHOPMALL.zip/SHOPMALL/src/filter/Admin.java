package filter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class Admin extends HandlerInterceptorAdapter{

	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object obj) throws Exception {
		
			request.setCharacterEncoding("UTF-8");
		    response.setCharacterEncoding("UTF-8");
			
		if(request.getSession().getAttribute("admin")!=null) {
			return true;
		}else {	
			    request.setAttribute("err", "您无权访问，请登录！");
				request.getRequestDispatcher("admin_login").forward(request, response);		
			return false;
		}
		
		
	}
}
