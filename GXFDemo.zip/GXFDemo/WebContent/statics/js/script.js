//login
var code; //在全局定义验证码    
//产生验证码   
window.onload = function() {
	createCode();
}

function createCode() {
	code = "";
	var codeLength = 4; //验证码的长度   
	var checkCode = document.getElementById("checkCode");
	var random = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
		'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'); //随机数   
	for(var i = 0; i < codeLength; i++) { //循环操作   
		var charIndex = Math.floor(Math.random() * 36); //取得随机数的索引   
		code += random[charIndex]; //根据索引取得随机数加到code上   
	}
	checkCode.value = code; //把code值赋给验证码   
}
//校验验证码   
function check(){
	var user1=document.getElementById("user").value;
	if(user1==""){
		alert("账户不能为空");
		document.getElementById("user").focus();
		return false;
		}
	else if(user1.length<6){
		alert("账户长度不小于11");
	document.getElementById("user").focus();
		return false;
		
	}
	var pass1=document.getElementById("pass").value;
	 if(pass1==""){
			alert("请输入密码");
			document.getElementById("pass").focus();
			return false;
			
		}
	 else if(pass1.length<6){
		 alert("密码长度不小于6");
		 document.getElementById("pass").focus();
		 return false;
	 }
	 var inputCode = document.getElementById("input").value.toUpperCase(); //取得输入的验证码并转化为大写         
		if(inputCode.length <= 0) { //若输入的验证码长度为0   
			alert("请输入验证码！"); //则弹出请输入验证码   
			return false;
		} else if(inputCode != code) { //若输入的验证码与产生的验证码不一致时   
			alert("验证码输入错误！"); //则弹出验证码输入错误   
			return false;
		window.onload =createCode();
			 //刷新验证码   
		} 
	 return true;
	 
		form1.submit();
	}

//register
function Rcheck(){
	var phone1=document.getElementById("id").value;
	   if(phone1.length != 11){
		 alert("请输入11位有效的手机号");
		 document.getElementById("id").focus();
		 return false;
	   }
	var user1=document.getElementById("name").value;
	if(user1==""){
		alert("昵称不能为空");
		document.getElementById("name").focus();
		return false;
		}
	else if(user1.length<3){
		alert("昵称长度不小于3");
	document.getElementById("name").focus();
		return false;
		
	}
	var pass1=document.getElementById("passwordone").value;
	 if(pass1==""){
			alert("请输入密码");
			document.getElementById("passwordone").focus();
			return false;
			
		}
	 else if(pass1.length<6){
		 alert("密码长度不小于6");
		 document.getElementById("passwordone").focus();
		 return false;
	 }
	 var pass2=document.getElementById("passwordtwo").value;
	   if(pass1!==pass2){
		 alert("前后输入的密码不一至！");
		 document.getElementById("passwordtwo").focus();
		 return false;
	 }
	   
	 return true;
	 
		form2.submit();
	}



$(function(){
	
	var note = $('#note'),
		ts = new Date(2012, 0, 1),
		newYear = true;
	
	if((new Date()) > ts){
		// The new year is here! Count towards something else.
		// Notice the *1000 at the end - time must be in milliseconds
		ts = (new Date()).getTime() + 10*24*60*60*1000;
		newYear = false;
	}
		
	$('#countdown').countdown({
		timestamp	: ts,
		callback	: function(days, hours, minutes, seconds){
			
			var message = "";
			
			message += days + " day" + ( days==1 ? '':'s' ) + ", ";
			message += hours + " hour" + ( hours==1 ? '':'s' ) + ", ";
			message += minutes + " minute" + ( minutes==1 ? '':'s' ) + " and ";
			message += seconds + " second" + ( seconds==1 ? '':'s' ) + " <br />";
			
			if(newYear){
				message += "left until the new year!";
			}
			else {
				message += "left to 10 days from now!";
			}
			
			note.html(message);
		}
	});
	
});
