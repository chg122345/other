package com.cg1.control;


import com.cg1.interceptors.UserInterceptors;
import com.cg1.model.Comment;
import com.jfinal.aop.Before;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.upload.UploadFile;
import com.cg1.model.Message;
import com.cg1.model.User;
@Before(UserInterceptors.class)
public class UserController extends Controller {

	@ActionKey("/removeuser")
	public  void removeuser() {
		removeSessionAttr("user");
		redirect("/index");
	}
   @ActionKey("/comment")
   public void comment() {
	   Comment comment=getModel(Comment.class);
	   comment.save();
	   redirect("/index");
	   
   }
   @ActionKey("/message")
   public void Message() {
	   Message mes=getModel(Message.class);
	   mes.save();
	   redirect("/index");
	   
   }
   @ActionKey("/user_content")
   public void Usercontent() {
	   render("user_content.jsp");
	   
   }
   @ActionKey("/user_revise")
   public void Userupdate() {	   
	   UploadFile files= getFile("favicon","touxiang");
	   User user=getModel(User.class);
	   user.set("favicon",files.getOriginalFileName()).update();
	   removeSessionAttr("user");
	   redirect("/index");
	   
   }
   @ActionKey("/user_udel")
   public void Userdel() {
	   String uid=getPara("uid");
	  new User().dao().deleteById(uid);	
	  removeSessionAttr("user");
	   redirect("/index");
	   
   }
}
