package control;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import model.Goods;
import model.UOrder;
import model.User;
import pages.PageModel;
import services.Services;


@Controller
@RequestMapping("/")
public class AdminController {
	
   @Autowired
   private Services services;
    
	/**
	 * 管理员登录处理
	 * @param request
	 * @param model
	 * @param name
	 * @param psd
	 * @return
	 */
    @RequestMapping(value="Adminlogin",method=RequestMethod.POST)
    public String adminlogin(HttpServletRequest request,Model model,@RequestParam("name") String name,@RequestParam("password") String psd) {
    	HttpSession session=request.getSession();
    	if(services.checkAdmin(name, psd)){
    		session.setAttribute("admin", name);
    		model.addAttribute("admin",name);
    		return "admin_content";
    		}else {
    	 request.setAttribute("err","用户名与密码不匹配！请重新登录！");
    	return "forward:admin_login";
    	}
    }
    
    /**
     * 修改管理员密码
     */
    @RequestMapping("admin_revise.m")
    public String reviseadmin(HttpServletRequest request) {
    	HttpSession session=request.getSession();
    	String oldname=(String)session.getAttribute("admin");
    	String oldpasd=request.getParameter("oldpassword");
    	String aname=request.getParameter("newname");
    	String apasd=request.getParameter("passwordone");
    	if(services.checkAdmin(oldname, oldpasd)) {
    		
    		services.reviseAdmin(aname, apasd, oldname, oldpasd);
    		return "redirect: admin_login";
    	}else {
    		return "admin_manage";
    		
    	}
    }
    /**
     * 退出处理
     * @return
     */
    @RequestMapping("removeadmin.m")
    public String removeadmin(HttpServletRequest request) {
 	   HttpSession session =request.getSession();
 	   session.invalidate();
 	   
 	   return "redirect: index";
    }
    
    @RequestMapping("/admin_manage.m")
    public String adminmanage() {
    	
    	return "admin_manage";
    }
    
	 @RequestMapping("/admin_content.m")
	   public String admincentent() {
		 
		   return "admin_content";
	   }
	 
	 @RequestMapping("/top")
	 public String top() {
		 
		 return "top";
	 }
	 @RequestMapping("/left.m")
	 public String left() {
		 
		 return "left";
	 }
	 /**
	  * 商品管理，先查询出所有商品再做分页
	  * @param request
	  * @param model
	  * @return
	  */
	 @RequestMapping("/goodsmanage.m")
	 public String adminmanagegoods(HttpServletRequest request,Model model) {
		 
		 List<Goods> list=services.selectGoods();
         PageModel pm = new PageModel(list, 5);
         int totalPages=pm.getTotalPages();
         String spage=request.getParameter("intpage");
         if(spage==null) {
        	 int intpage=1;
        	 List sublist = pm.getObjects(intpage);
    		 model.addAttribute("goods", sublist );
    		 model.addAttribute("page",intpage);
    		 model.addAttribute("tpages",totalPages);
         }
         else {
         int intpage= Integer.parseInt(spage);
		 List sublist = pm.getObjects(intpage);
		 model.addAttribute("goods", sublist );
		 model.addAttribute("page",intpage);
		 model.addAttribute("tpages",totalPages);
         }
		 return "goodsmanage";
	 }
	 
	  /**
	   * 根据商品id删除商品
	   * @param gid
	   * @return
	   */
	 @RequestMapping("/admin_delgoods.m")
	 public String admindelgoods(@RequestParam("gid") String gid) {
		services.delGoods(gid);
		  return "redirect:goodsmanage.m";
	 }
	 
	
	 @RequestMapping("/admin_addgoods.m")
	 public String addgoods() {
		 return "admin_addgoods";
	 } 
	 
	/**
	 * 处理新增商品信息 
	 * @param request
	 * @param img 商品图片
	 * @return
	 * @throws UnsupportedEncodingException
	 */
 @RequestMapping(value="/doaddgoods",method=RequestMethod.POST)
 public String doaddgoods(HttpServletRequest request,@RequestParam("img") MultipartFile img) throws UnsupportedEncodingException {
	     
	        try {
	        	//获取文件名
	        	String originalName = img.getOriginalFilename();
	        	//获取文件后缀
	        	String suffix = img.getOriginalFilename().substring(img.getOriginalFilename().lastIndexOf("."));
	            if(img != null && originalName != null && originalName.length()>0){
	            	byte[] bytes=img.getBytes();//获取上传数据
	            
	           	String path =request.getServletContext().getRealPath("/Style/goodsimg/");
	            File Saveimg = new File(path);
	            if(!Saveimg.exists()) {
	            	Saveimg.mkdirs();
	       }
	            String picNewName=request.getParameter("id")+suffix;

	            File file = new File(path+picNewName); 
	            FileCopyUtils.copy(bytes, file);
	            Goods goods=new Goods();  
	            goods.setGoodsimg(picNewName);
	            goods.setGid(request.getParameter("id"));
	            goods.setName(request.getParameter("name"));
	            goods.setAccount(Integer.parseInt(request.getParameter("number")));
	            goods.setPrice(Float.parseFloat(request.getParameter("price")));
	            goods.setState(request.getParameter("explain"));
	           services.addGoods(goods);   
	            
              }
        
	} catch (IllegalStateException e) {
	                
	                e.printStackTrace();
	           } catch (IOException e) {
	                
	                e.printStackTrace();
	            }    
	        return "redirect:goodsmanage.m";
	        }
 
	/**
	 * 查看用户，分页
	 * @param request
	 * @param model
	 * @return
	 */
	@RequestMapping("/usersmanage.m")
	 public String adminmanageuser(HttpServletRequest request,Model model) {
		 
		 List<User> list=services.selectallUser();
		 PageModel pm = new PageModel(list, 5);
         int totalPages=pm.getTotalPages();
         String spage=request.getParameter("intpage");
         if(spage==null) {
        	 int intpage=1;
        	 List sublist = pm.getObjects(intpage);
    		 model.addAttribute("users", sublist );
    		 model.addAttribute("page",intpage);
    		 model.addAttribute("tpages",totalPages);
         }
         else {
         int intpage= Integer.parseInt(spage);
		 List sublist = pm.getObjects(intpage);
		 model.addAttribute("users", sublist );
		 model.addAttribute("page",intpage);
		 model.addAttribute("tpages",totalPages);
         }
		  
		 return "admin_usermanage";
	 }
	
	/**
	 * 查看订单 分页
	 * @param request
	 * @param model
	 * @return
	 */
	@RequestMapping("admin_orders.m")
	public String selAllorder(HttpServletRequest request,Model model) {
		HttpSession session=request.getSession();
		List<UOrder> uorder=services.selallOrder();
		PageModel pm = new PageModel(uorder, 5);
        int totalPages=pm.getTotalPages();
        String spage=request.getParameter("intpage");
        if(spage==null) {
       	 int intpage=1;
       	 List sublist = pm.getObjects(intpage);
       	session.setAttribute("uorder", sublist);
   		 model.addAttribute("page",intpage);
   		 model.addAttribute("tpages",totalPages);
        }
        else {
        int intpage= Integer.parseInt(spage);
		 List sublist = pm.getObjects(intpage);
		 session.setAttribute("uorder", sublist);
		 model.addAttribute("page",intpage);
		 model.addAttribute("tpages",totalPages);
        }
		return "admin_orders";
	}
}
