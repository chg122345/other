package untiltools;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;


public class Installutils {
	
	private static String dburl;
	private static String dbdriver;
	private static String dbuser;
	private static String dbpassword;
	private static String dbdialect;

	public static void init(String driver, String url, String user, String password ,String dialect) {
		
		dburl = url;
		dbuser = user;
		dbpassword = password;
		dbdriver = driver;
		dbdialect=dialect;
	}
	
	public static boolean checkdatabase() {
		
		 Connection conn=null;
			try {
				Class.forName(dbdriver);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			try {
				conn= DriverManager.getConnection(dburl,dbuser,dbpassword);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			if(conn!=null) {		
				return true;
			}else {
				return false;
			}
		
	}

	public static boolean createDbProperties(HttpServletRequest request) {
		String path=request.getServletContext().getRealPath("/WEB-INF/classes/Resources/jdbc.properties");
		Properties p = new Properties();		
		p.setProperty("isinstall", "1");
		p.setProperty("jdbc.password", dbpassword);
		p.setProperty("jdbc.user", dbuser);	
		p.setProperty("jdbc.url",dburl);
		p.setProperty("jdbc.driver", dbdriver);		
		p.setProperty("jdbc.dialect", dbdialect);		
		File pFile = new File(path, "jdbc.properties");
		return save(p, pFile);
	}

	private static boolean save(Properties p, File pFile) {
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(pFile);
			p.store(fos, "Auto create by GXF");
		} catch (Exception e) {
			return false;
		} finally {
			if (fos != null)
				try {
					fos.close();
				} catch (IOException e) {
				}
		}
		return true;
	}
	

}
