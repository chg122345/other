package com.cg1.tools;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import com.jfinal.kit.PathKit;

public class Installutils {
	
	private static String dburl;
	private static String dbdriver;
	private static String dbuser;
	private static String dbpassword;
	public static DbDialect mDialect=new MysqlDialect();

	public static void init(String driver, String url, String user, String password) {
		
		dburl = url;
		dbuser = user;
		dbpassword = password;
		dbdriver = driver;
	}
	
	public static boolean checkdatabase() {
		
		 Connection conn=null;
			try {
				Class.forName(dbdriver);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			try {
				conn= DriverManager.getConnection(dburl,dbuser,dbpassword);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			if(conn!=null) {		
				return true;
			}else {
				return false;
			}
		
	}

	public static boolean createDbProperties() {
		Properties p = new Properties();
//		p.put("jdbc.driver", dbdriver);
//		p.put("jdbc.url", dburl);
//		p.put("jdbc.user", dbuser);
//		p.put("jdbc.password", dbpassword);
		p.setProperty("jdbc.password", dbpassword);
		p.setProperty("jdbc.user", dbuser);	
		p.setProperty("jdbc.url",dburl);
		p.setProperty("jdbc.driver", dbdriver);
		File pFile = new File(PathKit.getRootClassPath(), "jdbc.properties");
		return save(p, pFile);
	}

	private static boolean save(Properties p, File pFile) {
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(pFile);
			p.store(fos, "Auto create by GXF");
		} catch (Exception e) {
			return false;
		} finally {
			if (fos != null)
				try {
					fos.close();
				} catch (IOException e) {
				}
		}
		return true;
	}
	
	
	public static void createGXFDatabase(){
		Connection conn = null;
		String installSql = mDialect.forInstall();
		System.out.println(installSql);
		try {
			Class.forName(dbdriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			conn = DriverManager.getConnection(dburl,dbuser,dbpassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			executeBatchSql(conn,installSql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		Statement pst = conn.createStatement();
//		pst.execute(installSql);
//		pst.close();
//		executeBatchSql(conn, installSql);

	}
	
	private static void executeBatchSql(Connection conn, String batchSql) throws SQLException {
		Statement pst = conn.createStatement();
		if (null == batchSql) {
			throw new SQLException("SQL IS NULL");
		}

		if (batchSql.contains(";")) {
			String sqls[] = batchSql.split(";");
			for (String sql : sqls) {
				if (null != sql && !"".equals(sql.trim()))
					pst.addBatch(sql);
			}
		} else {
			pst.addBatch(batchSql);
		}
		pst.executeBatch();
		pst.close();
	}

}
