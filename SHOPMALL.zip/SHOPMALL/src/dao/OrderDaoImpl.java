package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import model.OrderItem;
import model.UOrder;

@Repository(value="OrderDao")
public class OrderDaoImpl implements OrderDao {

	@Autowired()
	private SessionFactory factory;
	
	public  Session session = null;
	
	 
	/**
	 * 创建订单
	 */
	@Override
	public void addOrder(UOrder order) {
		
		try {
			session=factory.openSession();
			session.beginTransaction();
			session.save(order);
			List<OrderItem> items=order.getItems();
			for(OrderItem item:items) {
				session.save(item);
			}
			session.getTransaction().commit();
		}catch(Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		if(session!=null) {
			if(session.isOpen()) {
				session.close();
			}
		}
		
	}
	
	/**
	 * 查看订单
	 */
	@Override
	public List<UOrder> selallOrder() {
		 List<UOrder> list=new  ArrayList<UOrder>();
		try {
			session=factory.openSession();
			session.beginTransaction();
			Query q = session.createQuery("from UOrder");  
	         list = q.list();
			session.getTransaction().commit();
		}catch(Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		if(session!=null) {
			if(session.isOpen()) {
				session.close();
			}
		}
		return list;
		
	}
	
	

    /**
    * 用户查看订单
    */
	@Override
	public List<UOrder> seluserOrder(String uid) {
		 List<UOrder> list=new  ArrayList<UOrder>();
			try {
				session=factory.openSession();
				session.beginTransaction();
				String hql="from UOrder where user='"+uid+"'";
				  Query q = session.createQuery(hql);
		         list = q.list();
				session.getTransaction().commit();
			}catch(Exception e) {
				e.printStackTrace();
				session.getTransaction().rollback();
			}
			if(session!=null) {
				if(session.isOpen()) {
					session.close();
				}
			}
			return list;
	}
	
    /**
     * 用户收货时修改订单状态
     */
	@Override
	public void updateOrder(String oid, String uid,int status) {
		
		try {
			session=factory.openSession();
			session.beginTransaction();
			String hql="update UOrder set status="+status+" where uid='"+uid+"' and orderid='"+oid+"'";
			  Query q = session.createQuery(hql);
			  q.executeUpdate();
			session.getTransaction().commit();
		}catch(Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		if(session!=null) {
			if(session.isOpen()) {
				session.close();
			}
		}
		
	}
	
    /**
     * 查看订单项
     */
	@Override
	public List<OrderItem> seluserOrderItem(String orderid) {
		List<OrderItem> list=new ArrayList<OrderItem>();
		try {
			session=factory.openSession();
			session.beginTransaction();
			String hql="from OrderItem where orderid='"+orderid+"'";
			  Query q = session.createQuery(hql);
	         list = q.list();
			session.getTransaction().commit();
		}catch(Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		if(session!=null) {
			if(session.isOpen()) {
				session.close();
			}
		}
		return list;
	}

	
	

	

}
