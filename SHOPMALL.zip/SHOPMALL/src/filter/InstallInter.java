package filter;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class InstallInter extends HandlerInterceptorAdapter {
	
public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object obj) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
	    response.setCharacterEncoding("UTF-8");
	    String path=request.getServletContext().getRealPath("/WEB-INF/classes/Resources/jdbc.properties");
		Properties p = new Properties();
	//	OutputStream output=new FileOutputStream(path);
		InputStream inStream = new FileInputStream(new File(path));
		p.load(inStream);
	//	System.out.println(path);
	    String ins=p.getProperty("isinstall");
	//    System.out.println(ins);
	    
	
	if(ins.equals("1")) {
		return true;
	}else {	
		response.sendRedirect(request.getContextPath()+"/install");
		return false;
	}
	
	
}

}
