package com.cg1.control;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg1.model.Article;
import com.cg1.model.User;
import com.cg1.service.GxfService;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;

public class FrontController extends Controller {

	@ActionKey("/index")
	public void index() {
//		String type=null;
//		type=getPara("type");
//		if(type==null) {
//			type="1";
//		}
		int page;
		String p=getPara("page");
		if(p==null) {
			page=1;
		}else {
			page=Integer.parseInt(p);
		}
		Page<Article> p1=GxfService.gxf.getallArticle01(page);
		List<Article> article1=p1.getList();
		int tpage=p1.getTotalPage();
		setSessionAttr("articles1",article1);
		setAttr("page",page);
		setAttr("tpages",tpage);
//		setSessionAttr("articles1",GxfService.gxf.getArticle("1"));
//		setSessionAttr("articles2",GxfService.gxf.getArticle("2"));
//		setSessionAttr("articles3",GxfService.gxf.getArticle("3"));
//		setSessionAttr("articles4",GxfService.gxf.getArticle("4"));
//		String aid=getPara("aid");	
//		setSessionAttr("commints",GxfService.gxf.getCommentbyaid(aid));	
		render("index.jsp");
	}
	@ActionKey("/register")
	public void regist() {
		render("register.jsp");
	}
	@ActionKey("/login")
	public void login() {
		render("login.jsp");
	}
	
	/**
	 * 处理注册, 存入数据库
	 */
	@ActionKey("/Register")
	public void Register() {
		User user=getModel(User.class);//接收一个对象
		user.save();
		render("index.jsp");
	}
	/**
	 * 登录处理 页面跳转
	 * @throws  
	 */
	@ActionKey("/Login")
	public void Login(){
		Map<String,String> result=new HashMap<String,String>();
		String id=getPara("user");
		String password=getPara("pass");
		User user=GxfService.gxf.checklogin(id, password);
		
		if(user!=null) {
			setSessionAttr("user",user);
			result.put("msg", "true");
	     renderJson(result);
		}else {
			
			setAttr("err", "用户信息有误，请重新登录！");
			result.put("msg", "flase");
		     renderJson(result);		
		}
		
		//System.out.println(result.get("msg"));
	}
	
	
	@ActionKey("/conarticle")
	public void conarticle() {
		String aid=getPara("aid");	
		setAttr("article",GxfService.gxf.getConArticle(aid));
		setAttr("comments",GxfService.gxf.getCommentbyaid(aid));	
		render("conarticle.jsp");
	}
}
