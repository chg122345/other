package com.cg1.interceptors;

import com.cg1.model.User;
import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;


public class AdminInterceptor implements Interceptor {

	@Override
	public void intercept(Invocation inv) {
		
		 Controller c = inv.getController();
		 User admin=(User)c.getSessionAttr("admin");
		if(admin!=null) {
			inv.invoke();
		}else {
			c.redirect("/admin_login");
		}
	}

}
