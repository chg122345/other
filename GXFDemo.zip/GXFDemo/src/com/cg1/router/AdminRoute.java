package com.cg1.router;

import com.cg1.control.AdminController;
import com.jfinal.config.Routes;

public class AdminRoute extends Routes {

	@Override
	public void config() {
		//addInterceptor(new AdminInterceptor());
		add("/admin",AdminController.class,"/WEB-INF/admin");
    
	}

}
