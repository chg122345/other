package control;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import model.OrderItem;
import model.UOrder;
import model.User;
import pages.PageModel;
import services.Services;
import shopcar.Cart;
import shopcar.CartItem;

@Controller
@RequestMapping("/")
public class UserController {
	
	 @Autowired
	 private Services services;	
	 
	 @RequestMapping("login")
	   public String login() {
		 
		   return "login";
	   }
	
	 @RequestMapping("register")
	 public String register() {
		 
		 return "register";
	 }
 
   /**
    * 接收注册信息，处理用户注册
    * @param request
    * @return
    */
   @RequestMapping("Register")
   public String adduser(HttpServletRequest request) {
	   String uid=request.getParameter("id");
	   String uname=request.getParameter("name");
	   String upsd=request.getParameter("passwordone");
	   String usex=request.getParameter("sex");
	   String address=request.getParameter("address");
	   String address2=request.getParameter("address2");
	   String uaddress=address+address2;
	   String uqq=request.getParameter("qq");
	User user=new User(uid,uname,upsd,usex,uaddress,uqq,0);
	services.addUser(user);
	   return "index";
   }
   
   /**
    * 验证用户登录
    * @param request
    * @return
    */
   @RequestMapping(value = "dologin", method = RequestMethod.POST)
   public String checkuser(HttpServletRequest request) {
	  String uid=request.getParameter("user");
	  String psd=request.getParameter("pass");
	  HttpSession session =request.getSession();
	  User user=services.checkUser(uid, psd);
	  String userid=user.getId();
	    if(userid!=null) {			   
		   session.setAttribute("user", user);
		   return "redirect: index";
		   
	   }else {
		   request.setAttribute("err","用户名与密码不匹配！请重新登录！");		   
	       return "forward:login";
	   }
   }
   
   /**
    * 退出登录
    * @param request
    * @return
    */
   @RequestMapping("removeuser.u")
   public String removeuser(HttpServletRequest request) {
	   HttpSession session =request.getSession();
	   session.invalidate();
	   
	   return "redirect: index";
   }
   /**
    * 用户创建订单
    * @param request
    * @return
    */
   @RequestMapping("/addorder.u")
	public String addOrder(HttpServletRequest request) {
	   SimpleDateFormat tempDate = new SimpleDateFormat("yyyyMMddHHmmss");
	   String datetime = tempDate.format(new Date(System.currentTimeMillis()));  	
		HttpSession session =request.getSession();
	    User user = (User)session.getAttribute("user");
	    Cart cart = (Cart)session.getAttribute("cart");
	    UOrder uorder=new UOrder();
	
	    uorder.setOrderid(datetime);
	    uorder.setTnumber(cart.getTotalnumber());
	    uorder.setTmoney(cart.getTotalmoney());
	    uorder.setAddress(user.getAddress());
	    uorder.setUser(user);
	    //单项
	    List<OrderItem> oItems = new ArrayList<OrderItem>();
	    for(Map.Entry<String, CartItem> em:cart.getItems().entrySet()) {
	    	
	    	//购物车中的购物项
	    	CartItem cItem=em.getValue();
	    	OrderItem oItem = new OrderItem();
	    	oItem.setOitemid(datetime+cItem.getGoods().getGid());
	    	oItem.setGoods(cItem.getGoods());
	    	oItem.setMoney(cItem.getMoney());
	    	oItem.setGname(cItem.getGoods().getName());
	    	oItem.setGprice(cItem.getGoods().getPrice());
	    	oItem.setNumber(cItem.getNumber());
	    	oItems.add(oItem);
	    	
	    }
	    	uorder.setItems(oItems);
	    	services.addOrder(uorder);
	    	request.setAttribute("uorder", uorder);
 
		return "redirect:shoporder.u";
		
	}
   /**
    * 用户查看订单
    * @param request
    * @return
    */
   @RequestMapping("shoporder.u")
   public String showOrder(HttpServletRequest request) {
	   HttpSession session =request.getSession();
	   User user=(User)session.getAttribute("user");
	   String uid=user.getId();
	   List<UOrder> uorder=services.seluserOrder(uid);
	   session.setAttribute("uorder", uorder);
	   return "shoporder";
   }
   
   /**
    * 查看订单项   分页
    * @param request
    * @param model
    * @return
    */
   @RequestMapping("shoporderitems.u")
   public String showOrderItem(HttpServletRequest request,Model model) {
	   HttpSession session =request.getSession();
	   String orderid=request.getParameter("orderid");
	   List<OrderItem> orderitem=services.seluserOrderItem(orderid);
	   
	   PageModel pm = new PageModel(orderitem, 4);
       int totalPages=pm.getTotalPages();
       String spage=request.getParameter("intpage");
       if(spage==null) {
      	 int intpage=1;
      	 List sublist = pm.getObjects(intpage);
      	 session.setAttribute("orderitem", sublist);
  		 model.addAttribute("page",intpage);
  		 model.addAttribute("tpages",totalPages);
       }
       else {
       int intpage= Integer.parseInt(spage);
		 List sublist = pm.getObjects(intpage);
		 session.setAttribute("orderitem", sublist);
		 model.addAttribute("page",intpage);
		 model.addAttribute("tpages",totalPages);
       }
	  
	   return "shoporderitems";  
    }
   
   /**
    * 
    * @return
    */
   @RequestMapping("user_content.u")
   public String usercontent() {
	   
	   return "user_content";
   }
   
   /**
    * 修改用户信息
    * @param request
    * @return
    */
   @RequestMapping("user_revise.u")
   public String userresvise(HttpServletRequest request) {
	   HttpSession session =request.getSession();
	   User user=(User)session.getAttribute("user");
	   String oldid=user.getId();
	   String oldpasd=user.getPassword();
	           String name=request.getParameter("name");
			   String password=request.getParameter("password");
			   String sex=request.getParameter("sex");
			   String address=request.getParameter("address");
			   String qq= request.getParameter("qq");		   
	   services.reviseUser(name, password, sex, address, qq, oldid, oldpasd);
	   return "redirect:index";
   }
}