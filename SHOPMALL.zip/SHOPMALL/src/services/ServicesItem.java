package services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.GoodsDao;
import dao.OrderDao;
import dao.UserDao;
import model.Goods;
import model.OrderItem;
import model.UOrder;
import model.User;

@Service(value="Services")
public class ServicesItem implements Services {
	@Autowired()
	private GoodsDao goodsDao;
	@Autowired()
	private OrderDao orderDao;
    @Autowired()
	private UserDao userDao;

	/**
	 * goods
	 */
	@Override
	public void addGoods(Goods goods) {
		goodsDao.addGoods(goods);

	}

	@Override
	public void delGoods(String gid) {
		goodsDao.delGoods(gid);

	}

	@Override
	public List<Goods> selectGoods() {
		
		return goodsDao.selectGoods();
	}

	@Override
	public List<Goods> selRGoods() {
	
		return goodsDao.selRGoods();
	}

	@Override
	public Goods selGoods(String gid) {
		
		return goodsDao.selGoods(gid);
	}
	
/**
 * order
 */ 
	
	@Override
	public void addOrder(UOrder order) {
		orderDao.addOrder(order);
	}

	@Override
	public List<UOrder> selallOrder() {
		
		return orderDao.selallOrder();
	}

	@Override
	public List<UOrder> seluserOrder(String uid) {
		
		return orderDao.seluserOrder(uid);
	}

	@Override
	public List<OrderItem> seluserOrderItem(String orderid) {
		
		return orderDao.seluserOrderItem(orderid);
	}

	@Override
	public void updateOrder(String oid, String uid, int status) {
		orderDao.updateOrder(oid, uid, status);

	}
    /**
     * user
     */
	@Override
	public void addUser(User user) {
		userDao.addUser(user);

	}

	@Override
	public void delUser(String uid) {
		userDao.delUser(uid);

	}

	@Override
	public List<User> selectallUser() {
		
		return userDao.selectallUser();
	}

	@Override
	public User checkUser(String uid, String psd) {
		
		return userDao.checkUser(uid, psd);
	}

	@Override
	public void reviseUser(String name, String password, String sex, String address, String qq, String oldid,
			String oldpasd) {
		userDao.reviseUser(name, password, sex, address, qq, oldid, oldpasd);

	}

	@Override
	public boolean checkAdmin(String name, String psd) {
		if(userDao.checkAdmin(name, psd)) {
			return true;
		}
		else {
		return false;
		}
	}

	@Override
	public void reviseAdmin(String aname, String apasd, String oldname, String oldpasd) {
		userDao.reviseAdmin(aname, apasd, oldname, oldpasd);

	}

	
}
