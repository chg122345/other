package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import model.Goods;

@Repository(value="goodsDao")
public class GoodsDAoImpl implements GoodsDao {

	@Autowired()
	private SessionFactory factory;
	
	public  Session session = null;
    
	/**
	 * 添加商品
	 */
	@Override
	public void addGoods(Goods goods) {
		try {
			session=factory.openSession();
			session.beginTransaction();
			session.save(goods);
			session.getTransaction().commit();
		}catch(Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		if(session!=null) {
			if(session.isOpen()) {
				session.close();
			}
		}

	}
   
	/**
	 * 根据商品id删除
	 */
	@Override
	public void delGoods(String gid) {
		try {
			session=factory.openSession();
			session.beginTransaction();
			String hql="delete Goods where gid='"+gid+"'";
			  Query query = session.createQuery(hql);
			  query.executeUpdate();
			//	Goods goods=(Goods)session.get(Goods.class,gid);
			session.getTransaction().commit();
		}catch(Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		if(session!=null) {
			if(session.isOpen()) {
				session.close();
			}
		}

	}

	/**
	 * 查看所有商品
	 */
	@Override
	public List<Goods> selectGoods() {
		List<Goods> list=new ArrayList<Goods>();
		try {
			session=factory.openSession();
			session.beginTransaction();
			Query q = session.createQuery("from Goods");  
	         list = q.list();
			session.getTransaction().commit();
		}catch(Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		if(session!=null) {
			if(session.isOpen()) {
				session.close();
			}
		}
		return list;
	}
	
   /**
    * 根据商品id查询
    */
	@Override
	public Goods selGoods(String gid) {
		Goods goods=new Goods();
		try {
			session=factory.openSession();
			session.beginTransaction();
			 goods=(Goods)session.get(Goods.class, gid);
			session.getTransaction().commit();
			
		}catch(Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		if(session!=null) {
			if(session.isOpen()) {
				session.close();
			}
		}

		return goods;
		
	}
	
	
/**
 * 查询最新添加的4条商品记录
 */
	@Override
	public List<Goods> selRGoods() {
		
		List<Goods> list=new ArrayList<Goods>();
		try {
			session=factory.openSession();
			session.beginTransaction();
			String hql="from Goods order by gid desc ";
			Query q = session.createQuery(hql);
			q.setFirstResult(0); 
			q.setMaxResults(4); 
	         list = q.list();
			session.getTransaction().commit();
		}catch(Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		if(session!=null) {
			if(session.isOpen()) {
				session.close();
			}
		}
		return list;
	}

}
