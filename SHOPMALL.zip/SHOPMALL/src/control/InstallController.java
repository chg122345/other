package control;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import untiltools.Installutils;

@Controller
@RequestMapping("/")
public class InstallController {
	
	@RequestMapping("/install")
	public String install() {
		return"install/index";
	}
	
	@RequestMapping("/step1")
	public String install2() {
		return"install/step1";
	}
	@RequestMapping("/step2")
	public String install3(HttpServletRequest request,HttpServletResponse response) {
		
		 String database=request.getParameter("database");
		    String name=request.getParameter("name");
		    String ip=request.getParameter("ip");
			String port=request.getParameter("port");
			String user=request.getParameter("user");
			String password=request.getParameter("password");
			String url=null;
			String driver=null;
			String dialect=null;
			
			//mysql 处理
			if(database.equals("mysql")) {
				
			url="jdbc:mysql://"+ip+":"+port+"/"+name+"?useUnicode=true&amp;characterEncoding=UTF-8";
			driver="com.mysql.jdbc.Driver";
			dialect="org.hibernate.dialect.MySQL5Dialect";
			
			}else if(database.equals("sqlserver")) {
				//sqlserver 处理
				driver="com.microsoft.sqlserver.jdbc.SQLServerDriver";
				url="jdbc:sqlserver://"+ip+":"+port+";DatabaseName="+name;
				dialect="org.hibernate.dialect.SQLServerDialect"; //设置hibernate sqlserver方言
			}
		Installutils.init(driver, url, user, password,dialect);
		if(Installutils.checkdatabase()) {
            Installutils.createDbProperties(request);
            return"install/success";
		}else{
			request.getSession().setAttribute("err", "数据库信息有误");
			return "redirect:step1";
		}
		
		
	}

}
