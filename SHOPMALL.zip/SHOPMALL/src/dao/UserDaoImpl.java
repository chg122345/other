package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import model.User;
import passpoint.ParseMD5;

@Repository(value="userDao")
public class UserDaoImpl implements UserDao {


	@Autowired()
	private SessionFactory factory;
	
	public  Session session = null;
	
	/**
	 * 用户注册
	 */
	@Override
	public void addUser(User user) {
		  String uid=user.getId();
		  String name=user.getName();
		  String passwd=user.getPassword();
		  String sex=user.getSex();
		  String address=user.getAddress();
		  String qq=user.getQq();
		  Integer purse=user.getPurse();	
		passwd=ParseMD5.parseStrToMd5U16(passwd);
		User user1=new User(uid,name,passwd,sex,address,qq,purse);
		try {
			session=factory.openSession();
			session.beginTransaction();
			session.save(user1);
			session.getTransaction().commit();
		}catch(Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		if(session!=null) {
			if(session.isOpen()) {
				session.close();
			}
		}

	}
	
	/**
	 * 删除用户
	 */
	@Override
	public void delUser(String uid) {
		
		try {
			session=factory.openSession();
			session.beginTransaction();
			User obj = (User) session.get(User.class, uid);  
           if (obj !=null ) {  
               session.delete(obj);  
           }
			session.getTransaction().commit();
		}catch(Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		if(session!=null) {
			if(session.isOpen()) {
				session.close();
			}
		}
	}
    
	/**
	 * 查看所有用户信息
	 */
	@Override
	public List<User> selectallUser() {
		List<User> list=new ArrayList<User>();
		try {
			session=factory.openSession();
			session.beginTransaction();
			 Query q = session.createQuery("from User");  
	         list = q.list();	            
			session.getTransaction().commit();
			
		}catch(Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		if(session!=null) {
			if(session.isOpen()) {
				session.close();
			}
		}
		return list;
		
		
	}

   /**
    * 用户登录验证
    */
	@Override
	public User checkUser(String uid, String psd) {
		User user=new User();
		psd=ParseMD5.parseStrToMd5U16(psd);	
		String hql = "FROM User WHERE ID='"+uid+"' AND PASSWORD='"+psd+"'";
		session=factory.openSession();
		session.beginTransaction();	
		Query q1=session.createQuery(hql);
		List<User> list1=q1.list();		
		for(User u1:list1)  {
			 user=u1;
		}
		
		return user;
		
	}

    /**
     * 管理员登录验证
     */
	@Override
	public boolean checkAdmin(String name, String psd) {
			
		String hql = "FROM Admin WHERE name='"+name+"' AND password='"+psd+"'";
		session=factory.openSession();
		session.beginTransaction();
		
		Query q1=session.createQuery(hql);
		List<User> list1=q1.list();
		if(list1!=null && list1.size()>0) {
			return true;
		}
		else {
			 return false;
		}
	}

/**
 * 修改管理员账号密码
 */
	@Override
	public void reviseAdmin(String aname,String apasd,String oldname,String oldpasd) {
		try {
			session=factory.openSession();
			session.beginTransaction();
			String hql="update Admin set name='"+aname+"',password='"+apasd+"' where name='"+oldname+"' and password='"+oldpasd+"'";
			  Query query = session.createQuery(hql);
			  query.executeUpdate();
			session.getTransaction().commit();
		}catch(Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		if(session!=null) {
			if(session.isOpen()) {
				session.close();
			}
		}
		
	}

/**
 * 
 * 用户信息修改
 */
@Override
public void reviseUser(String name, String password, String sex, String address, String qq, String oldid,
		String oldpasd) {
	password=ParseMD5.parseStrToMd5U16(password);	
	try {
		session=factory.openSession();
		session.beginTransaction();
		String hql="update User set name='"+name+"',password='"+password+"',sex='"+sex+"',address='"+address+"',qq='"+qq+"' where id='"+oldid+"' and password='"+oldpasd+"'";
		  Query query = session.createQuery(hql);
		  query.executeUpdate();
		session.getTransaction().commit();
	}catch(Exception e) {
		e.printStackTrace();
		session.getTransaction().rollback();
	}
	if(session!=null) {
		if(session.isOpen()) {
			session.close();
		}
	}
}
}
