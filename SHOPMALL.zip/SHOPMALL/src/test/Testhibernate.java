package test;


import dao.UserDaoImpl;
import model.User;

public class Testhibernate {
	
	
	
	public void add() {
		User u=new User("8910", "admin", "admin", "", "", "88888",0);
		//UserDao usd=new UserDao();
		UserDaoImpl uds=new UserDaoImpl();
		uds.addUser(u);
		System.out.println("success");

	}	
}
