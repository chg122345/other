package control;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import model.Goods;
import services.Services;

/**
 * Handles requests for the application home page.
 */
@Controller
@RequestMapping("/")
public class HomeController {
	
	@Autowired
	private Services services;
	 
	/**
	 * 先到数据库查询商品信息，再跳转index页面显示
	 * @param model
	 * @return
	 */
	 @RequestMapping("/index")
	   public String index(Model model) {
		 List<Goods> list =services.selectGoods();
		 List<Goods> rgoods=services.selRGoods();
		 model.addAttribute("goods",list);
		 model.addAttribute("rgoods",rgoods);
		   return "index";
	   }
	 @RequestMapping("/")
	 public String Cindex(Model model) {
		 List<Goods> list =services.selectGoods();
		 List<Goods> rgoods=services.selRGoods();
		 model.addAttribute("goods",list);
		 model.addAttribute("rgoods",rgoods);
		 return "index";
	 }
	 
	/**
	 * 拦截进入初始化数据库参数
	 * @return
	 */
//	 @RequestMapping("/install")
//	 public String Config() {
//		
//		 return "redirect:install";
//	 }
	 
	 /**
	  * 
	  * @return
	  */
	 @RequestMapping("/admin_login")
	 public String adminlogin() {
		 
		 return "admin_login";
		 
	 }
	
}
