package model;

import java.io.Serializable;

public class OrderItem implements Serializable {

	      private String oitemid;
	      private int number;
	      private  float money;
	      private String gname;
	      private float gprice;
	      //m-1
	      private Goods goods;
	      //m-1
	      private UOrder uorder;
	      
	      
		public String getGname() {
			return gname;
		}
		public void setGname(String gname) {
			this.gname = gname;
		}
		public float getGprice() {
			return gprice;
		}
		public void setGprice(float gprice) {
			this.gprice = gprice;
		}
		public String getOitemid() {
			return oitemid;
		}
		public void setOitemid(String oitemid) {
			this.oitemid = oitemid;
		}
		public int getNumber() {
			return number;
		}
		public void setNumber(int number) {
			this.number = number;
		}
		public float getMoney() {
			return money;
		}
		public void setMoney(float money) {
			this.money = money;
		}
		public Goods getGoods() {
			return goods;
		}
		public void setGoods(Goods goods) {
			this.goods = goods;
		}
		public UOrder getUorder() {
			return uorder;
		}
		public void setUorder(UOrder uorder) {
			this.uorder = uorder;
		}
	      
		
	      
}
