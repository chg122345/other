package com.cg1.tools;

import java.util.HashMap;
import java.util.Map;

import com.jfinal.plugin.druid.DruidPlugin;
/**
 * 
 * @author Chen_9g
 * @date 2017年12月23日下午4:20:18
 * @Copyright 2017
 */
public abstract class DbDialect {

	// key:classSimpleName.toLowerCase value:tableName
	protected static Map<String, String> tableMapping = new HashMap<String, String>();

	public static void mapping(String key, String value) {
		tableMapping.put(key, value);
	}

	public abstract String forShowTable();

	public abstract String forInstall();

	public abstract String forSelect(String tableName);

	public abstract String forDelete(String tableName);

	public abstract String forSelectCount(String tableName);

	public abstract String forPaginateFrom(String tableName, String where);

	public abstract String forInsertWebName();

	public abstract String forInsertFirstUser();

	/**
	 * becuse the table name is uncertainty, invoke this method convert sql to
	 * correct.
	 * 
	 * @param sql
	 * @return
	 */
	public abstract String doTableConvert(String sql);

	public abstract DruidPlugin createDuidPlugin(String dbUrl,String dbName, String dbUser, String dbPassword);

}
