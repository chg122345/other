package com.cg1.model;

import com.jfinal.plugin.activerecord.Model;

public class Message extends Model<Message> {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final Message dao=new Message().dao();
	
	private long id;
	private String user_id;
	private String user_phone;
	private String user_email;
	private String content;
	
	
	public Message() {
		super();
	}
	
	public String getuser_id() {
		return user_id;
	}
	public void setuser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getuser_phone() {
		return user_phone;
	}
	public void setuser_phone(String user_phone) {
		this.user_phone = user_phone;
	}
	public String getuser_email() {
		return user_email;
	}
	public void setuser_email(String user_email) {
		this.user_email = user_email;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

}
