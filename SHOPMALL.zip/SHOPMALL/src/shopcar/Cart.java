package shopcar;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import model.Goods;

public class Cart implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Map<String,CartItem> items=new HashMap<String,CartItem>();
	private int totalnumber;
	private float totalmoney;
	
	
	
	public int getTotalnumber() {
		   totalnumber=0;
		for(Map.Entry<String, CartItem> g:items.entrySet()) {
		    totalnumber +=g.getValue().getNumber();
			}
		return totalnumber;
	}
	
	
	public void setTotalnumber(int totalnumber) {
		
		this.totalnumber = totalnumber;
	}
	
	
	public float getTotalmoney() {
		totalmoney=0;
   for(Map.Entry<String, CartItem> g:items.entrySet()) {
	    totalmoney +=g.getValue().getMoney();
		}
		return totalmoney;
	}
	
	
	public void setTotalmoney(float totalmoney) {
		this.totalmoney = totalmoney;
	}
	
	
	public Map<String, CartItem> getItems() {
		return items;
	}
	
	

	//添加购物车
	public void addGoods(Goods goods){
		
		if(items.containsKey(goods.getGid())) {
			//购物车有该商品
			CartItem item=items.get(goods.getGid());
			item.setNumber(item.getNumber()+1);
		}else {
			
			CartItem item=new CartItem(goods);
			item.setNumber(1);
			items.put(goods.getGid(), item);
		}
		
	}	
	
	
	
	
	
}
