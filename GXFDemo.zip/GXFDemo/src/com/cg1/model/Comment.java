package com.cg1.model;

import com.jfinal.plugin.activerecord.Model;

public class Comment extends Model<Comment> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final Comment dao=new Comment();
	
	public User getUser() { 
		return User.dao.findById(get("id")); 
   }
	private long id;
	private String comment;
	private String user_favicon;
	private String user_id;
	private String user_nickname;
	private String article_id;
	private int status;//状态 1通过审批 0 flase

	
	
	public Comment() {
		super();
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getcomment() {
		return comment;
	}
	public void setcomment(String comment) {
		this.comment = comment;
	}
	
	public String getUser_favicon() {
		return user_favicon;
	}

	public void setUser_favicon(String user_favicon) {
		this.user_favicon = user_favicon;
	}

	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getArticle_id() {
		return article_id;
	}
	public void setArticle_id(String article_id) {
		this.article_id = article_id;
	}
	
	public String getUser_nickname() {
		return user_nickname;
	}
	public void setUser_nickname(String user_nickname) {
		this.user_nickname = user_nickname;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}


}
