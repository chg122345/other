package com.cg1.interceptors;

import com.cg1.model.User;
import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;

public class UserInterceptors implements Interceptor {

	@Override
	public void intercept(Invocation inv) {
		 Controller c = inv.getController();
		 User user=(User)c.getSessionAttr("user");
		if(user!=null) {
			inv.invoke();
		}else {
			c.redirect("/login");
		}

	}

}
