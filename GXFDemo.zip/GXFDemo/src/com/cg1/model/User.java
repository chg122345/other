package com.cg1.model;

import java.util.List;

import com.jfinal.plugin.activerecord.Model;

public class User extends Model<User> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final User dao=new User().dao();
	public List<Comment> getCommints() {
		return Comment.dao.find("select * from gxf_commint where user_id=?", get("id"));
		}
	
	private String id;
	private String nickname;
	private String password;
	private int power;
	private String sex;
	private String address;
	private String tel;
	private String qq;
    private String favicon;
	
	
	public User() {
		super();
	}



	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getNickname() {
		return nickname;
	}



	public void setNickname(String nickname) {
		this.nickname = nickname;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public int getPower() {
		return power;
	}



	public void setPower(int power) {
		this.power = power;
	}



	public String getSex() {
		return sex;
	}



	public void setSex(String sex) {
		this.sex = sex;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getTel() {
		return tel;
	}



	public void setTel(String tel) {
		this.tel = tel;
	}



	public String getQq() {
		return qq;
	}



	public void setQq(String qq) {
		this.qq = qq;
	}



	public String getFavicon() {
		return favicon;
	}



	public void setFavicon(String favicon) {
		this.favicon = favicon;
	}
	
	
	

}
