package com.cg1.config;

import com.cg1.control.FileUploadController;
import com.cg1.control.InstallController;
import com.cg1.model.Article;
import com.cg1.model.Comment;
import com.cg1.model.Message;
import com.cg1.model.User;
import com.cg1.model.Webmes;
import com.cg1.router.AdminRoute;
import com.cg1.router.FrontRoute;
import com.cg1.tools.GXF;
import com.jfinal.config.Constants;
import com.jfinal.config.Handlers;
import com.jfinal.config.Interceptors;
import com.jfinal.config.JFinalConfig;
import com.jfinal.config.Plugins;
import com.jfinal.config.Routes;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.ActiveRecordPlugin;
import com.jfinal.plugin.activerecord.dialect.MysqlDialect;
import com.jfinal.plugin.c3p0.C3p0Plugin;
import com.jfinal.render.ViewType;
import com.jfinal.template.Engine;

/**
 * 
 * @author Chen_9g
 * @date 2017年12月23日下午4:18:30
 * @Copyright 2017
 */
public class GXFConfig extends JFinalConfig {

	@Override
	public void configConstant(Constants me) {
		
		me.setBaseUploadPath("conentimg");
		me.setViewType(ViewType.JSP);
		me.setEncoding("UTF-8");
		me.setMaxPostSize(1024 * 1024 * 10);
		me.setDevMode(true);
		me.setError401View("err.jsp");
		me.setError403View("err.jsp");
		me.setError404View("err.jsp");
		me.setError500View("err.jsp");
	}

	@Override
	public void configRoute(Routes me) {
		
		me.add(new FrontRoute());//前端路由
		me.add(new AdminRoute());//后台路由
		me.add("/imgcontent", FileUploadController.class);//上传文件专用路由
		me.add("/install", InstallController.class,"/WEB-INF/install");//初始化安装路径
		
	}

	@Override
	public void configEngine(Engine me) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void configPlugin(Plugins me) {
		
		
		if(GXF.isInstalled()) {
		PropKit.use("jdbc.properties");
		C3p0Plugin dp = new  C3p0Plugin(PropKit.get("jdbc.url"), PropKit.get("jdbc.user"), PropKit.get("jdbc.password"),PropKit.get("jdbc.driver"));  
	//	dp.start();
		me.add(dp); 
		ActiveRecordPlugin arp = new ActiveRecordPlugin(dp); 
	//	arp.setDevMode(true);
	//	arp.setDialect(new SqlServerDialect());
		arp.setDialect(new MysqlDialect());
		arp.setShowSql(true);
		me.add(arp);
		arp.addMapping("gxf_user", "id",User.class);
		arp.addMapping("gxf_article","id", Article.class);
		arp.addMapping("gxf_comment","id",Comment.class);
		arp.addMapping("gxf_message", "id",Message.class);
		arp.addMapping("gxf_webmes", "web_name",Webmes.class);
		}
		
	}

	@Override
	public void configInterceptor(Interceptors me) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void configHandler(Handlers me) {
		// TODO Auto-generated method stub
		
	}

}
