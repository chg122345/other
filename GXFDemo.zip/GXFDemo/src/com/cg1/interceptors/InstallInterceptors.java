package com.cg1.interceptors;

import com.cg1.tools.GXF;
import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;

public class InstallInterceptors implements Interceptor {

	@Override
	public void intercept(Invocation inv) {
		if (GXF.isInstalled()) {
			inv.getController().redirect("/index");
		} else {
			inv.invoke();
		}

	}

}
