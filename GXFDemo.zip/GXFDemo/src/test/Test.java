package test;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import com.cg1.tools.MysqlDialect;

public class Test {

	public static void main(String[] args) throws IntrospectionException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
//		Controltest c=new Controltest();
//		
//	
//		
//		Method[] method=c.getClass().getDeclaredMethods();
//		for(Method me:method) {
//		 ActioTest a=me.getAnnotation(ActioTest.class);
//			if(a!=null) {
//				PropertyDescriptor pd=new PropertyDescriptor(me.getName(), Controltest.class);
//				Method set=pd.getWriteMethod();
//				if(set!=null) {
//					String value=a.value();
//					me.setAccessible(true);
//					set.invoke(c, value);
//				}
//			}
//	
//	}
		MysqlDialect m=new MysqlDialect();
		String sql=m.forInstall();
		System.out.println(sql);
//		Page<Article> a=new Article().dao().paginate(1, 2,"select * ","from gxf_article");
//for(Article a1:a.getList()) {
//	System.out.println(a1.getTitle());
//	
//}
//		System.out.println(c.Test1());
	}

}
