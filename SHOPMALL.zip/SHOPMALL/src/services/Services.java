package services;

import java.util.List;

import model.Goods;
import model.OrderItem;
import model.UOrder;
import model.User;

public interface Services {
	 //goods
	 public void addGoods(Goods goods);
	 public void delGoods(String gid);
	 public List<Goods> selectGoods();
	 public List<Goods> selRGoods();
	 public Goods selGoods(String gid);
	 //order
	 public void addOrder(UOrder order);
     public List<UOrder> selallOrder(); 
	 public List<UOrder> seluserOrder(String uid);
	 public List<OrderItem> seluserOrderItem(String orderid);
	 public void updateOrder(String oid,String uid,int status);
	 //user
	 public void addUser(User user);
	 public void delUser(String uid);
	 public List<User> selectallUser();
	 public User checkUser(String uid,String psd);
	 public void reviseUser(String name, String password, String sex, String address, String qq,String oldid,String oldpasd);
	 public boolean checkAdmin(String name,String psd);
	 public void reviseAdmin(String aname,String apasd,String oldname,String oldpasd);
}
