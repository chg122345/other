package com.cg1.control;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg1.interceptors.AdminInterceptor;
import com.cg1.model.Article;
import com.cg1.model.Comment;
import com.cg1.model.Message;
import com.cg1.model.User;
import com.cg1.model.Webmes;
import com.cg1.service.GxfService;
import com.jfinal.aop.Before;
import com.jfinal.aop.Clear;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.upload.UploadFile;

@Before(AdminInterceptor.class)
public class AdminController extends Controller {
	
	@Clear
	@ActionKey("/admin_login")
	public void login() {
		
		render("login.jsp");
	}
	
    /**
     * 处理登录 true则跳转主页  flase跳转login
     */
	@Clear
    @ActionKey("/admin_dologin")
    public void dologin() {
		Map<String,String> result=new HashMap<String,String>();
    	String id=getPara("id");
    	String password=getPara("password");
    	User admin=GxfService.gxf.checklogin(id, password);	
    	if(admin!=null) {
    		if(admin.getInt("power")==1) {
			setSessionAttr("admin",admin);
			result.put("msg", "true");
		     renderJson(result);
		//	System.out.println(admin.getInt("power"));
			//redirect("/admin");
			}else {
				setAttr("err","您不是管理员!");
			 //   render("login.jsp");
				result.put("msg", "tflase");
			     renderJson(result);
			}
		}else {
			setAttr("err","密码不正确!");
			result.put("msg", "flase");
			System.out.println();
		     renderJson(result);
		  //  render("login.jsp");
		}
    }
    @ActionKey("/admin")
    public void admin() {
    	
    	render("admin_index.jsp");
    }
    @ActionKey("/admin_remove")
    public void adminremove() {
    	removeSessionAttr("admin");
    	redirect("/index");
    }
    
    
//    @ActionKey("/editor")
//    public void editor() {
//    	render("editor.jsp");
//    }
  
    
 /*---------------------article 文章----------------------------*/
 
    @ActionKey("/article_add")
    public void addarticle() {
    	render("article_add.jsp");
    }
    /**
     * 文章添加处理
     */
    @ActionKey("/admin_submitcontent")
    public void submit() {
    	UploadFile files= getFile("article.avatar");
    	String title=getPara("article.title");
    	String ftitle=getPara("article.ftitle");//副标题
    	String type=getPara("article.type");//类型
    	String abstrac=getPara("article.abstrac");//摘要
    	String author=getPara("article.author");//编者
    	String sources=getPara("article.sources");//来源
    	String content=getPara("article.content");//内容
    	int comments=getParaToInt("article.comments");    //允许评论
    	String avatar=files.getOriginalFileName();//图片路径   	   
		new Article().set("title", title).set("ftitle", ftitle).set("type", type).set("abstrac", abstrac)
				.set("author", author).set("sources", sources).set("content", content)
				.set("comments", comments).set("avatar", avatar).save(); 
    	render("/welcome.jsp");   	
    }
    @ActionKey("/article_list")
    public void selarticle() {
    	List<Article> list=GxfService.gxf.getallArticle();
    	setAttr("article",list);
    //	setAttr("intpage",intpage);
    	render("article_list.jsp");
    }
    @ActionKey("/article_del")
    public void delarticle() {
    	
    	int aid=getParaToInt("aid");
    	new Article().dao().deleteById(aid);
    	GxfService.gxf.delCommentByAid(aid);
    	redirect("/article_list");
    }
    /*---------------------------message 留言---------------------------*/
    @ActionKey("/message_list")
    public void selmessang() {
    	List<Message> list=GxfService.gxf.getMessage();
    	setAttr("message",list);
     	render("message_list.jsp");
    }
    @ActionKey("/message_del")
    public void delmessang() {
    	int mid=getParaToInt("mid");
    	new Message().dao().deleteById(mid);
    	redirect("/message_list");
    }
    
    @ActionKey("/comment_list")
    public void selcomment() {
    	List<Comment> list=GxfService.gxf.getAllComment();
    	setAttr("comments",list);
     	render("comment_list.jsp");
    }
    @ActionKey("/comment_del")
    public void delcomment() {
    	int cid=getParaToInt("cid");
    	new Comment().dao().deleteById(cid);
    	redirect("/comment_list");
    }
    @ActionKey("/comment_update")
    public void updatecomment() {
    	int cid=getParaToInt("cid");
    	GxfService.gxf.examine(cid);
    	redirect("/comment_list");
    }
    /*------------------------------user 会员-------------------------------------*/
    @ActionKey("/user_list")
    public void seluser() {
    	List<User> list=GxfService.gxf.getUser();
    	setAttr("user",list);
    	render("user_list.jsp");
    }
    @ActionKey("/user_del")
    public void deluser() {
    	String uid=getPara("uid");
    	new User().dao().deleteById(uid);
    	redirect("/user_list");
    }
    @ActionKey("/user_updatepassword")
    public void updateuserpassword() {
    	String uid=getPara("uid");
    	setAttr("uid",uid);
    	render("user_updatepassword.jsp");
    }
    @ActionKey("/user_update")
    public void updateuser() {
    	String uid=getPara("uid");
   // 	System.out.println(uid);
    	String password=getPara("newpassword");
    User user=new User().dao().findById(uid);
    user.set("password", password).update();
    	redirect("/user_list");
    }
    @ActionKey("/user_show")
    public void showuser() {
    	String uid=getPara("uid");
    	User user=new User().dao().findById(uid);
    	setAttr("user",user);
    	render("user_show.jsp");
    }
    /**---------------------------system 网站----------------------------------------*/
    @ActionKey("/system_base")
    public void systembase() {
    	render("system_base.jsp");
    }
    @ActionKey("/system_mes")
    public void systemMse() {
    	Webmes web=getModel(Webmes.class);
    	web.save();
    	redirect("/admin");
    }
}
