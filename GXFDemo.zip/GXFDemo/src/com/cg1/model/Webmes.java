package com.cg1.model;

import com.jfinal.plugin.activerecord.Model;

public class Webmes extends Model<Webmes> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final Webmes dao=new Webmes().dao();
	
	private String web_name;
	private String web_intro;
	private String web_copyright;
	private String web_number;
	
	
	public Webmes() {
		super();
	}
	public String getWeb_name() {
		return web_name;
	}
	public void setWeb_name(String web_name) {
		this.web_name = web_name;
	}
	public String getWeb_intro() {
		return web_intro;
	}
	public void setWeb_intro(String web_intro) {
		this.web_intro = web_intro;
	}
	public String getWeb_copyright() {
		return web_copyright;
	}
	public void setWeb_copyright(String web_copyright) {
		this.web_copyright = web_copyright;
	}
	public String getWeb_number() {
		return web_number;
	}
	public void setWeb_number(String web_number) {
		this.web_number = web_number;
	}
	

}
