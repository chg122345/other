package com.cg1.service;

import java.util.List;

import com.cg1.model.Article;
import com.cg1.model.Comment;
import com.cg1.model.Message;
import com.cg1.model.User;
import com.jfinal.plugin.activerecord.Page;

public class GxfService {
    
	public static final GxfService gxf = new GxfService();
	private static Article dao = new Article(); 
	private static Comment dao2 = new Comment(); 
	private static User dao3 = new User(); 
	private static Message dao4 = new Message(); 
	/**
	 * 查询所有文章
	 * @return 文章集合 分页
	 */
	public List<Article> getallArticle() {
		String sql="select * from gxf_article";
		List<Article> list=dao.find(sql);	
		return list;
	}
	public Page<Article> getallArticle01(int PageNumber) {
		Page<Article> list=dao.paginate(PageNumber, 2, "select *","from gxf_article");
		return list;
	}
	
	/**
	 * 根据类型查文章
	 * @return
	 */
	
	public List<Article> getArticle(String type ) {
		String Atype=null;
		if( type.equals("1")) {
			Atype="其他类型";		
		}else if(type.equals("2")) {
			Atype="学习资讯";
		}else if(type.equals("3")) {
			Atype="新闻资讯";
		}else if(type.equals("4")) {
			Atype="百科资讯";
		}
				
		String sql="select * from gxf_article where type=?";//order by id desc limit 1
		List<Article> list=dao.find(sql,Atype);		
//		Page<Article> page=dao.paginate(1, 2, "select *","from gxf_article where type=?",Atype);
//		List<Article> list=page.getList();
		return list;
	}
	/**
	 * 根据文章id查看文章详情
	 * @param aid
	 * @return  article
	 */
	public Article getConArticle(String aid) {
		
		return dao.findById(aid);
	}
	/**
	 * 根据文章id查看用户得评论
	 * @param aid
	 * @return  用户评论集合
	 */
	public List<Comment> getCommentbyaid(String aid){
		String sql="select * from gxf_comment where status=1 and article_id=?";
		List<Comment> list=dao2.find(sql,aid);
		return list;
	}
	/**
	 * 查询所有评论
	 * @return
	 */
	public List<Comment> getAllComment(){
		String sql="select * from gxf_comment";
		List<Comment> list=dao2.find(sql);
		return list;
	}
	/**
	 * 验证用户登录 
	 * @param id
	 * @param password
	 * @return  success 返回User false 返回null
	 */
	public User checklogin(String id,String password) {
		String sql="select * from gxf_user where id=? and password=?"; 
		User user=dao3.findFirst(sql,id,password);
		if(user!=null) {
			return user;
		}else {
		return null;
		}
	}
	/**
	 * 管理员审批评论
	 * @param cid
	 */
	public void examine(int cid) {
		Comment.dao.findById(cid).set("status", 1).update();
	}
	/**
	 * 查询留言信息
	 * @return 留言list
	 */
	public List<Message> getMessage(){
		String sql="select * from gxf_message";
		List<Message> list=dao4.find(sql);
		return list;
	}
	/**
	 * 查询会员
	 * @return
	 */
	public List<User> getUser(){
		String sql="select * from gxf_user";
		List<User> list=dao3.find(sql);
		return list;
	}
	/**
	 * 根据文章id删除评论
	 * @param aid
	 */
	public void delCommentByAid(int aid) {
		String sql="delete from gxf_comment where article_id=?";
		dao2.findFirst(sql,aid);
	}
	
}
