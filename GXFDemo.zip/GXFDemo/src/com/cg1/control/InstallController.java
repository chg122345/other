package com.cg1.control;

import com.cg1.interceptors.InstallInterceptors;
import com.cg1.tools.Installutils;
import com.jfinal.aop.Before;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
@Before(InstallInterceptors.class)
public class InstallController extends Controller {
	@ActionKey("/")
	public void install() {
		
		render("index.jsp");
	}
	@ActionKey("/step1")
	public void install1() {
		
		render("step1.jsp");
	}
	@SuppressWarnings("unused")
	@ActionKey("/step2")
	public void install2(){
		
		    String database=getPara("database");
		    String name=getPara("name");
		    String ip=getPara("ip");
			String port=getPara("port");
			String user=getPara("user");
			String password=getPara("password");
			String url=null;
			String driver=null;
			String dialect=null;
			
			//mysql 处理
			if(database.equals("mysql")) {
				
			url="jdbc:mysql://"+ip+":"+port+"/"+name+"?useUnicode=true&amp;characterEncoding=UTF-8";
			driver="com.mysql.jdbc.Driver";
			dialect="org.hibernate.dialect.MySQL5Dialect";
			
			}else if(database.equals("sqlserver")) {
				//sqlserver 处理
				driver="com.microsoft.sqlserver.jdbc.SQLServerDriver";
				url="jdbc:sqlserver://"+ip+":"+port+";DatabaseName="+name;
				dialect="org.hibernate.dialect.SQLServerDialect"; //设置hibernate sqlserver方言
			}
			Installutils.init(driver, url, user, password);
			if(Installutils.checkdatabase()) {				
				Installutils.createGXFDatabase();
				Installutils.createDbProperties();
				render("success.jsp");//安装完成
			}else {
				setSessionAttr("err", "数据库信息有误！");
				//数据库信息有误
				redirect("/step1");
			}	
	}

}
