package com.cg1.router;

import com.cg1.control.FrontController;
import com.cg1.control.UserController;
import com.jfinal.config.Routes;

public class FrontRoute extends Routes {

	@Override
	public void config() {
		add("/user",UserController.class,"/WEB-INF/front");
		add("/front",FrontController.class,"/WEB-INF/front");

	}

}
