'CREATE DATABASE GXF;' ' 你自己的数据库名'

'USE GXF;'

CREATE TABLE `gxf_user` (
  `id` int(11) NOT NULL,
  `nickname` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `power`  int(11) NOT NULL default 0,
  `sex` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `tel` varchar(45) NOT NULL,
  `qq` varchar(45) NOT NULL,
   `favicon` varchar(45),
  `created` datetime default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `gxf_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `ftitle` text NOT NULL,
  `type` varchar(45) NOT NULL,
  `abstrac` varchar(45) NOT NULL,
   `author` varchar(45) NOT NULL,
  `sources` varchar(45) NOT NULL,
  `content` LONGTEXT NOT NULL,
  `comments` int(11) NOT NULL,
  `created` datetime default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `gxf_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(45) NOT NULL,
  `user_phone` varchar(45) NOT NULL,
  `user_email` varchar(45) NOT NULL,
  `content` text NOT NULL,
  `created` datetime default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `gxf_webmes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `web_name` varchar(45) NOT NULL,
  `web_intro` text NOT NULL,
  `web_copyright` text NOT NULL,
  `web_number` varchar(45),
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `gxf_comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `comment` LONGTEXT NOT NULL,
  `user_id` varchar(45) NOT NULL,
  `user_nickname` varchar(45) NOT NULL,
  `article_id` varchar(45) NOT NULL,
  `status` int(11) NOT NULL default 0,
  `created` datetime default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
