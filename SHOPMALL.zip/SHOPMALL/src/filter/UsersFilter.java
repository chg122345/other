package filter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;

public class UsersFilter implements HandlerInterceptor {

	
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object obj) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
	    response.setCharacterEncoding("UTF-8");
	
	if(request.getSession().getAttribute("user")!=null) {
		return true;
	}else {	
		    request.setAttribute("err", "您还没有登录会员，请先登录！");
			request.getRequestDispatcher("login").forward(request, response);		
		return false;
	}
	
	
}
}
