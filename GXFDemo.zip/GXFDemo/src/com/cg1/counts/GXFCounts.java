package com.cg1.counts;

public class GXFCounts {
	
	public static final String USER_IS_LONGN="1";

}
