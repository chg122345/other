package test;

import java.io.File;
import java.io.IOException;

public class Getpath {
	

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		 File directory = new File("");//设定为当前文件夹
		    
	      //  System.out.println(directory.getCanonicalFile());//返回类型为File
	        System.out.println(directory.getCanonicalPath());//获取标准的路径  ，返回类型为String
	     //   System.out.println(directory.getAbsoluteFile());//返回类型为File
	        System.out.println(directory.getAbsolutePath());//获取绝对路径，返回类型为String
	}

}
