package dao;

import java.util.List;

import model.Goods;

public interface GoodsDao {

	public void addGoods(Goods goods);
	public void delGoods(String gid);
	public List<Goods> selectGoods();
	public List<Goods> selRGoods();
	public Goods selGoods(String gid);
}
