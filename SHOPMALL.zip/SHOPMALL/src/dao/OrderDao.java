package dao;

import java.util.List;

import model.OrderItem;
import model.UOrder;

public interface OrderDao {

	public void addOrder(UOrder order);
	
    public List<UOrder> selallOrder();
     
	 public List<UOrder> seluserOrder(String uid);
	 public List<OrderItem> seluserOrderItem(String orderid);
	 	 
	 public void updateOrder(String oid,String uid,int status);
}
