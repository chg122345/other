package control;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import model.Goods;
import services.Services;
import shopcar.Cart;

@Controller
@RequestMapping("/")
public class ShopCarController {
	
	@Autowired
    private Services services;
	
    @RequestMapping("/shopcar.u")
	public String showcar() {
		
		return "shopcar";
	}
	
    /**
     * 处理新增购物项
     * @param request
     * @param gid 商品id
     * @return
     */
	@RequestMapping("/addcar.u")
	public String addCar(HttpServletRequest request,@RequestParam("gid") String gid) {
		Goods goods=services.selGoods(gid);	
		HttpSession session =request.getSession();
	  Cart cart = (Cart)session.getAttribute("cart");
		if(cart==null) {
			cart=new Cart();
			session.setAttribute("cart", cart);
		}
		cart.addGoods(goods);
		
		return "redirect:shopcar.u";
		
	}
	
	/**
	 * 处理移除购物项
	 * @param request
	 * @param gid
	 * @return
	 */
	@RequestMapping("/delcar.u")
	public String delCar(HttpServletRequest request,@RequestParam("gid") String gid) {
		HttpSession session =request.getSession();
		  Cart cart = (Cart)session.getAttribute("cart");
		  cart.getItems().remove(gid);
		
		return "redirect:shopcar.u";
	}
	
	
	/**
	 * 清空购物车
	 * @param request
	 * @return
	 */
	@RequestMapping("/clearcar.u")
	public String clearcar(HttpServletRequest request) {
		HttpSession session =request.getSession();
		  Cart cart = (Cart)session.getAttribute("cart");
		  cart.getItems().clear();
		return "redirect:index";
	}
	
}
