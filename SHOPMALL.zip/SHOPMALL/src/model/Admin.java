package model;

public class Admin {

	private String name;
	private String password;
	private int rank;
	
	public Admin() {	
	
	}
	
	
	public Admin(String name, String password, int rank) {
		super();
		this.name = name;
		this.password = password;
		this.rank = rank;
	}


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	
	
}
