package shopcar;

import java.io.Serializable;

import model.Goods;

public class CartItem implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Goods goods;
	private int number;
	private float money;
	public CartItem(Goods goods) {
		this.goods=goods;
	}
	
	
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public float getMoney() {
		return goods.getPrice()*number;
	}
	public void setMoney(float money) {
		this.money = money;
	}
	public Goods getGoods() {
		return goods;
	}

	
	
}
