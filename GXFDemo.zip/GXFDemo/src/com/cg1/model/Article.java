package com.cg1.model;

import com.jfinal.plugin.activerecord.Model;

public class Article extends Model<Article> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final Article dao=new Article().dao();
	private long id;
	private String title;//标题
	private String ftitle;//副标题
	private String type;//类型
	private String abstrac;//摘要
	private String author;//编者
	private String sources;//来源
	private String content;//内容
	private int comments;    //允许评论
	private String avatar;//图片路径
	
	
	public Article() {
		super();
	}


	public Article(String title, String ftitle, String type, String abstrac, String author, String sources,
			String content, int comments, String avatar) {
		super();
		this.title = title;
		this.ftitle = ftitle;
		this.type = type;
		this.abstrac = abstrac;
		this.author = author;
		this.sources = sources;
		this.content = content;
		this.comments = comments;
		this.avatar = avatar;
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getFtitle() {
		return ftitle;
	}


	public void setFtitle(String ftitle) {
		this.ftitle = ftitle;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public String getAbstrac() {
		return abstrac;
	}


	public void setAbstrac(String abstrac) {
		this.abstrac = abstrac;
	}


	public String getAuthor() {
		return author;
	}


	public void setAuthor(String author) {
		this.author = author;
	}


	public String getSources() {
		return sources;
	}


	public void setSources(String sources) {
		this.sources = sources;
	}


	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}


	public int getComments() {
		return comments;
	}


	public void setComments(int comments) {
		this.comments = comments;
	}


	public String getAvatar() {
		return avatar;
	}


	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}


	
	
	

}
