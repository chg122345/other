package dao;

import java.util.List;
import model.User;

public interface UserDao {
	
    public void addUser(User user);

	public void delUser(String uid);

	public List<User> selectallUser();
	
	public User checkUser(String uid,String psd);
	public void reviseUser(String name, String password, String sex, String address, String qq,String oldid,String oldpasd);
	public boolean checkAdmin(String name,String psd);
	public void reviseAdmin(String aname,String apasd,String oldname,String oldpasd);
   
}
