package model;

import java.io.Serializable;
import java.util.*;

public class UOrder implements Serializable {
 
        
		 private String orderid;
         private int tnumber;
         private float tmoney;         
         private int status;//订单状态   
         private String address;
         //1-m
         private User user;
         //m-1
         private List<OrderItem> items = new ArrayList<OrderItem>();
         
        public UOrder() {
        	
        }
        
        
		public String getAddress() {
			return address;
		}


		public void setAddress(String address) {
			this.address = address;
		}


		public String getOrderid() {
			return orderid;
		}

		public void setOrderid(String orderid) {
			this.orderid = orderid;
		}

		public int getTnumber() {
			return tnumber;
		}

		public void setTnumber(int tnumber) {
			this.tnumber = tnumber;
		}

		public float getTmoney() {
			return tmoney;
		}

		public void setTmoney(float tmoney) {
			this.tmoney = tmoney;
		}

		public int getStatus() {
			return status;
		}

		public void setStatus(int status) {
			this.status = status;
		}

		public User getUser() {
			return user;
		}

		public void setUser(User user) {
			this.user = user;
		}

		public List<OrderItem> getItems() {
			return items;
		}

		public void setItems(List<OrderItem> items) {
			this.items = items;
		}
        
        

		
        
		
}
