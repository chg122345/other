package com.cg1.tools;

import java.io.File;

import com.jfinal.kit.PathKit;

public class GXF {
   
	
	private static boolean isInstalled = false;

	public static boolean isInstalled() {
		if (!isInstalled) {
			File dbConfig = new File(PathKit.getRootClassPath(), "jdbc.properties");
			isInstalled = dbConfig.exists();
		}
		return isInstalled;
		
	}
}
