package model;

public class User {
  private String id;
  private String name;
  private String password;
  private String sex;
  private String address;
  private String qq;
  private Integer purse;
  public User() {
	  
  }
  
public User(String id, String name, String password, String sex, String address, String qq, Integer purse) {
	super();
	this.id = id;
	this.name = name;
	this.password = password;
	this.sex = sex;
	this.address = address;
	this.qq = qq;
	this.purse = purse;
}

public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getSex() {
	return sex;
}
public void setSex(String sex) {
	this.sex = sex;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getQq() {
	return qq;
}
public void setQq(String qq) {
	this.qq = qq;
}
public Integer getPurse() {
	return purse;
}
public void setPurse(Integer purse) {
	this.purse = purse;
}


}
