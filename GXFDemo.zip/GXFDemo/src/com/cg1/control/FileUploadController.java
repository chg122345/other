package com.cg1.control;

import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.Ret;
import com.jfinal.upload.UploadFile;

public class FileUploadController extends Controller {
	@ActionKey("/imgcontent")
	public void index() {
		if ("config".equals(getPara("action"))) {
			render("/utf8-jsp/jsp/config.json");
			return;
			}
			// "upfile" 来自 config.json 中的 imageFieldName 配置项
			UploadFile file = getFile("upfile");
			String fileName = file.getFileName();
	        String[] typeArr = fileName.split("\\.");
	        String orig = file.getOriginalFileName();
	        long size = file.getFile().length();
	        String url = "/GXF/contentimg/"+fileName;
	        Ret ret = Ret.create("state", "SUCCESS")  //下面这几个都是必须返回给ueditor的数据
	                .set("url", url)  //文件上传后的路径
	                .set("title", fileName)  //文件名称
	                .set("original", orig)  
	                .set("type", "."+typeArr[1])
	                .set("size", size);
	        renderJson(ret);
	    }


	}

