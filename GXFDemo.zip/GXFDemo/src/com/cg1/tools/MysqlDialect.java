package com.cg1.tools;

import com.jfinal.kit.PathKit;
import com.jfinal.plugin.druid.DruidPlugin;

import java.io.File;

import com.cg1.tools.FileUtils;

public class MysqlDialect extends DbDialect {

	@Override
	public String forShowTable() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String forInstall() {
		String SqlFilePath = PathKit.getWebRootPath() + "/WebContent/WEB-INF/install/sql/gxf.sql";
		String sql_text = FileUtils.readString(new File(SqlFilePath));
		System.out.println(sql_text);
			//	.replace("{table_prefix}", tablePrefix).replace("{charset}", "utf8mb4");

		return sql_text;
	}

	@Override
	public String forSelect(String tableName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String forDelete(String tableName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String forSelectCount(String tableName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String forPaginateFrom(String tableName, String where) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String forInsertWebName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String forInsertFirstUser() {
		
		return "INSERT INTO `gxf_user` (id, nickname, password, power) "
				+ "VALUES (?,?,?,?)";
	}

	@Override
	public String doTableConvert(String sql) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DruidPlugin createDuidPlugin(String dbUrl, String dbName, String dbUser, String dbPassword) {
		DruidPlugin druidPlugin = new DruidPlugin(dbUrl, dbUser, dbPassword);
	//	druidPlugin.addFilter(new StatFilter());

		return druidPlugin;
		
	}

}
